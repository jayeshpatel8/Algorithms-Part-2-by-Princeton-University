import edu.princeton.cs.algs4.Digraph;
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.Stack;
import edu.princeton.cs.algs4.Queue;

public class SAP {
    private int length;               // length shortest path between
    private int ancestor;             // shortest ancestor of V and W
    private Digraph dupG;
    private int[] distToA;            // distToA[v] = length of shortest V->v path
    private int[] distToB;            // distToB[v] = length of shortest W->v path
    private boolean[] visitedA;        // marked1[v] = is there an V->v path?
    private boolean[] visitedB;        // marked2[v] = is there an W->v path?
    private Stack<Integer> stackA;    // store changed auxiliary array1 entries
    private Stack<Integer> stackB;    // store changed auxiliary array1 entries

    // constructor takes a digraph (not necessarily a DAG)
    public SAP(Digraph G) {
        if (G == null) {
            throw new IllegalArgumentException("Arg to SAP() is null");
        }

        dupG = new Digraph(G);

        distToA = new int[G.V()];
        distToB = new int[G.V()];
        visitedA = new boolean[G.V()];
        visitedB = new boolean[G.V()];
        stackA = new Stack<Integer>();
        stackB = new Stack<Integer>();
    }

    // length of shortest ancestral path between v and w; -1 if no such path
    public int length(int v, int w) {
        perform_bfs(v, w);
        return length;
    }

    // a common ancestor of v and w that participates in a shortest ancestral path; -1 if no such path
    public int ancestor(int v, int w) {
        perform_bfs(v, w);
        return ancestor;
    }

    // length of shortest ancestral path between any vertex in v and any vertex in w; -1 if no such path
    public int length(Iterable<Integer> v, Iterable<Integer> w) {
        perform_bfs(v, w);
        return length;
    }

    // a common ancestor that participates in shortest ancestral path; -1 if no such path
    public int ancestor(Iterable<Integer> v, Iterable<Integer> w) {
        perform_bfs(v, w);
        return length;
    }

    private void perform_bfs(int v, int w) {
        checkVertex(v);
        checkVertex(w);
        length = -1;
        ancestor = -1;
        distToA[v] = 0;
        distToB[w] = 0;
        visitedA[v] = true;
        visitedB[w] = true;
        stackA.push(v);
        stackB.push(w);
        Queue<Integer> q1 = new Queue<Integer>();
        Queue<Integer> q2 = new Queue<Integer>();
        q1.enqueue(v);
        q2.enqueue(w);
//        for (int i = 0; i < dupG.V(); i++)
        //          StdOut.printf(" %d ", distToA[v]);
        //    StdOut.printf(" \n");
        bfs(q1, q2);
    }

    private void perform_bfs(Iterable<Integer> v, Iterable<Integer> w) {
        checkVertex(v);
        checkVertex(w);
        // using two bfs to compute sap
        length = -1;
        ancestor = -1;
        Queue<Integer> q1 = new Queue<Integer>();
        Queue<Integer> q2 = new Queue<Integer>();
        for (int v1 : v) {
            visitedA[v1] = true;
            stackA.push(v1);
            distToA[v1] = 0;
            q1.enqueue(v1);
        }
        for (int w1 : w) {
            visitedB[w1] = true;
            stackB.push(w1);
            distToB[w1] = 0;
            q2.enqueue(w1);
        }
        bfs(q1, q2);

    }

    // run two bfs alternating back and forth bewteen q1 and q2
    private void bfs(Queue<Integer> q1, Queue<Integer> q2) {
        while (!q1.isEmpty() || !q2.isEmpty()) {
            if (!q1.isEmpty()) {
                int v = q1.dequeue();
                if (visitedB[v]) {
                    if (distToA[v] + distToB[v] < length || length == -1) {
                        ancestor = v;
                        //StdOut.printf(" length =%d , distToA[%d]= %d, distToB[%d]=%d", length, v, distToA[v], v, distToB[v]);
                        length = distToA[v] + distToB[v];

                    }
                }
                // stop adding new vertex to queue if the distance exceeds the length
                if (distToA[v] < length || length == -1) {
                    for (int w : dupG.adj(v)) {
                        if (!visitedA[w]) {
                            distToA[w] = distToA[v] + 1;
                            visitedA[w] = true;
                            stackA.push(w);
                            q1.enqueue(w);

                            // StdOut.println("push " + w + " into q1");
                        }
                    }
                }
            }
            if (!q2.isEmpty()) {
                int v = q2.dequeue();
                if (visitedA[v]) {
                    if (distToA[v] + distToB[v] < length || length == -1) {
                        ancestor = v;
                        //StdOut.printf(" length =%d , distToA[%d]= %d, distToB[%d]=%d", length, v, distToA[v], v, distToB[v]);
                        length = distToA[v] + distToB[v];
                    }
                }
                // stop adding new vertex to queue if the distance exceeds the length
                if (distToB[v] < length || length == -1) {
                    for (int w : dupG.adj(v)) {
                        if (!visitedB[w]) {
                            distToB[w] = distToB[v] + 1;
                            visitedB[w] = true;
                            stackB.push(w);
                            q2.enqueue(w);

                            // StdOut.println("push " + w + " into q2");
                        }
                    }
                }
            }
        }
        init();    // reinitialize auxiliary array for next bfs
    }

    // init auxiliary array for bfs
    private void init() {
        while (!stackA.isEmpty()) {
            int v = stackA.pop();
            visitedA[v] = false;
        }
        while (!stackB.isEmpty()) {
            int v = stackB.pop();
            visitedB[v] = false;
        }
    }

    // throw an IllegalArgumentException unless {@code 0 <= v < V}
    private void checkVertex(int v) {
        int V = visitedA.length;
        if (v < 0 || v >= V)
            throw new IllegalArgumentException("vertex " + v + " is not between 0 and " + (V - 1));
    }

    // throw an IllegalArgumentException unless {@code 0 <= v < V}
    private void checkVertex(Iterable<Integer> vertices) {
        if (vertices == null) {
            throw new IllegalArgumentException("argument is null");
        }
        int V = visitedA.length;
        for (int v : vertices) {
            if (v < 0 || v >= V) {
                throw new IllegalArgumentException("vertex " + v + " is not between 0 and " + (V - 1));
            }
        }
    }

    // do unit testing of this class
    public static void main(String[] args) {
        In in = new In(args[0]);
        Digraph G = new Digraph(in);
        SAP sap = new SAP(G);
        while (!StdIn.isEmpty()) {
            int v = StdIn.readInt();
            int w = StdIn.readInt();
            //StdOut.printf("v = %d -> w = %d : ", v, w);
            int length = sap.length(v, w);
            int ancestor = sap.ancestor(v, w);
            StdOut.printf("length = %d, ancestor = %d\n", length, ancestor);
        }
    }
}
