import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.Digraph;
import edu.princeton.cs.algs4.SET;
import edu.princeton.cs.algs4.ST;
import edu.princeton.cs.algs4.Topological;

public class WordNet {
    private ST<String, SET<Integer>> synsets;    // noun and ids contain the noun
    private ST<Integer, String> id_nouns;
    private Digraph hypernyms;
    private int total_id;
    private SAP sap;

    // constructor takes the name of the two input files
    public WordNet(String synsets, String hypernyms) {
        if (synsets == null || hypernyms == null) {
            throw new IllegalArgumentException("Arg to WordNet() is null");
        }
        In synset = new In(synsets);
        this.synsets = new ST<String, SET<Integer>>();
        id_nouns = new ST<Integer, String>();

        while (synset.hasNextLine()) {
            total_id++;
            String str = synset.readLine();
            String[] fields = str.split(",");
            int id = Integer.parseInt(fields[0]);
            id_nouns.put(id, fields[1]);
            String[] nouns = fields[1].split(" ");
            for (int i = 0; i < nouns.length; i++) {
                if (this.synsets.contains(nouns[i])) {
                    this.synsets.get(nouns[i]).add(id);
                } else {
                    SET<Integer> ids = new SET<Integer>();
                    ids.add(id);
                    this.synsets.put(nouns[i], ids);
                }
            }
        }
        // Build diGraph
        this.hypernyms = new Digraph(total_id);
        In hypernym = new In(hypernyms);
        boolean[] vertex = new boolean[total_id];
        int total_v = 0;                          // total number of vertices having a out edge
        while (hypernym.hasNextLine()) {
            String str = hypernym.readLine();
            String[] fields = str.split(",");
            int v = Integer.parseInt(fields[0]);
            for (int i = 1; i < fields.length; i++) {
                int w = Integer.parseInt(fields[i]);
                this.hypernyms.addEdge(v, w);
            }
            if (!vertex[v] && fields.length != 1) {
                total_v++;
            }
            vertex[v] = true;
        }
        if (total_id - total_v != 1) {
            throw new IllegalArgumentException("Not a one root digraph");
        }
        Topological t = new Topological(this.hypernyms);
        if (!t.hasOrder()) {
            throw new IllegalArgumentException("Not a DAG");
        }
        sap = new SAP(this.hypernyms);
    }

    // returns all WordNet nouns
    public Iterable<String> nouns() {
        return synsets.keys();
    }

    // is the word a WordNet noun?
    public boolean isNoun(String word) {
        if (word == null) {
            throw new IllegalArgumentException("Arg to isNoun() is null");
        }
        return synsets.contains(word);
    }

    // distance between nounA and nounB (defined below)
    public int distance(String nounA, String nounB) {
        if (nounA == null || nounB == null) {
            throw new IllegalArgumentException("Arg to distance() is null");
        }
        if (!isNoun(nounA) || !isNoun(nounB)) {
            throw new IllegalArgumentException("Arg to distance() is not a WordNet noun");
        }
        SET<Integer> A = synsets.get(nounA);
        SET<Integer> B = synsets.get(nounB);
        if (A.size() == 1 && B.size() == 1) {
            return (sap.length(A.max(), B.max()));
        } else {
            return (sap.length(A, B));
        }
    }

    // a synset (second field of synsets.txt) that is the common ancestor of nounA and nounB
    // in a shortest ancestral path (defined below)
    public String sap(String nounA, String nounB) {
        if (nounA == null || nounB == null) throw new IllegalArgumentException("Arg to sap() is null");
        if (!isNoun(nounA) || !isNoun(nounB)) throw new IllegalArgumentException("Arg to sap() is not a WordNet noun");
        SET<Integer> A = synsets.get(nounA);
        SET<Integer> B = synsets.get(nounB);
        if (A.size() == 1 && B.size() == 1) {
            return id_nouns.get(sap.ancestor(A.max(), B.max()));
        } else {
            return id_nouns.get(sap.ancestor(A, B));
        }
    }

    // do unit testing of this class
    public static void main(String[] args) {
    }
}
